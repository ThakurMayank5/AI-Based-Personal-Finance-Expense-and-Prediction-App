import { Platform } from 'react-native';

// For a physical phone, set EXPO_PUBLIC_API_URL to your computer's LAN address,
// e.g. http://192.168.1.20:42069. Android emulators can use http://10.0.2.2:42069.
const fallbackUrl = Platform.OS === 'web' ? 'http://localhost:42069' : 'http://10.19.185.151:42069';
export const API_URL = (process.env.EXPO_PUBLIC_API_URL ?? fallbackUrl).replace(/\/$/, '');

export type User = { id: number; email: string; display_name: string };
export type Transaction = { id: number; amount: number; date: string; note: string; created_at: string };
export type Dashboard = {
  month: string;
  summary: { total: number; transaction_count: number; previous_month_total: number; change_percent: number | null };
  monthly_totals: { month: string; total: number }[];
  recent_transactions: Transaction[];
};
export type Prediction = { forecast: number; next_month: string; history_months: number; method: string };

export class ApiError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
  }
}

async function request<T>(path: string, options: RequestInit = {}, token?: string): Promise<T> {
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      Accept: 'application/json',
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });
  if (!response.ok) {
    let message = 'Something went wrong. Please try again.';
    try {
      const body = (await response.json()) as { detail?: string };
      message = body.detail ?? message;
    } catch {
      // A non-JSON server error still receives a useful app message.
    }
    throw new ApiError(message, response.status);
  }
  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

export const api = {
  ping: () => request<{ message: string }>('/ping'),
  register: (email: string, display_name: string, password: string) =>
    request<User>('/auth/register', { method: 'POST', body: JSON.stringify({ email, display_name, password }) }),
  login: (email: string, password: string) =>
    request<{ token: string; expires_at: string; user: User }>('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),
  logout: (token: string) => request<void>('/auth/logout', { method: 'POST' }, token),
  dashboard: (token: string) => request<Dashboard>('/dashboard', {}, token),
  transactions: (token: string) => request<Transaction[]>('/transactions', {}, token),
  addTransaction: (token: string, amount: number, transactionDate: string, note: string) =>
    request<Transaction>('/transactions', { method: 'POST', body: JSON.stringify({ amount, date: transactionDate, note }) }, token),
  deleteTransaction: (token: string, id: number) => request<void>(`/transactions/${id}`, { method: 'DELETE' }, token),
  prediction: (token: string) => request<Prediction>('/prediction', {}, token),
};
